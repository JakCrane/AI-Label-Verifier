import React, { useState, useRef, useEffect } from 'react';
import { Button, Tooltip, Box, ButtonBase, Typography } from '@mui/material';
import FileUploadIcon from '@mui/icons-material/FileUpload';
import CancelIcon from '@mui/icons-material/Cancel';
import axios from 'axios';

const FileSelectButton = ({fileKey, fileType, formData, setFormData}) => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [fileName, setFileName] = useState(null)

  const handleFileChange = (event) => {
    const file = event.target.files[0]
    setTimeout(() => {
        console.log(file,'file',fileKey)}, 1000);
    
    setSelectedFile(file);
    setFileName(file.name);
    formData.set(fileKey, file);
    setTimeout(() => {
        console.log(formData.get(fileKey),'file')}, 1000);
    console.log(formData.get(fileKey));
  };
  const resetFileChange = () => {
    console.log('file reset called')
    setSelectedFile(null);
    setFileName(null);
    formData.set(fileKey, null)
    setFormData(formData);

  }

  return (
    <Box>
      {selectedFile ? 
        <div>
            <ButtonBase 
              sx={{
                border: '2px solid #1976d2',
                borderRadius: '10px',
                backgroundColor: '#1976d2',
                margin:'0 20px',
              }}>
              <Typography variant="button" sx={{ color: 'white',paddingX:'10px'}}>
                {fileName}
              </Typography>
              <Tooltip title="Deselect File">
                <Button component="span" onClick={resetFileChange}  sx={{ minWidth: 0}}>
                  <CancelIcon sx={{ color: 'white'}}/>
                </Button>
              </Tooltip>
            </ButtonBase>
        </div>
      : 
        <div>
          <input
            type="file"
            id="file-input"
            accept={fileType}
            style={{ display: 'none' }}
            onChange={handleFileChange}
          />
          <label htmlFor="file-input">
            <Button variant="contained" component="span">
              <FileUploadIcon />
            </Button>
          </label>
        </div>}
    </Box>
  );
};

export default FileSelectButton;
