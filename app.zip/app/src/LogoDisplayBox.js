import React from 'react';
import { Typography, Box } from '@mui/material';


const LogoDisplayBox = ({obj}) => {
  console.log(obj, 'obj')
  const scoreOneHundred = obj.match_score*100;
  
  console.log(scoreOneHundred)
  console.log(obj.image)
  return(
    <Box width='33vw' height='80vh' sx={{
      padding: '10px',
      border: '1px solid black',
      display: 'flex',
      flexDirection:'column',
      alignItems: 'center',}}
    >
      <Typography variant="h6">Logo</Typography>
      <Typography textAlign={'center'} margin={'10px 0'}>{scoreOneHundred.toFixed(2)}% matching</Typography>
      
      <img src={`data:image/jpeg;base64,${obj.match_image}`} width='100%'/>
        
    </Box>
    
  );
};

export default LogoDisplayBox;
