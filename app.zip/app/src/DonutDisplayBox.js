import React from 'react';
import { Typography, Box } from '@mui/material';


const DonutDisplayBox = ({obj}) => {
  console.log(obj, 'obj')
  console.log(obj.text)

  function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
  }
  if (!obj.text) {
    return null; // Return null or a placeholder component if data is undefined or null
  }
  return(
    <Box width='33vw' height='80vh' sx={{
      padding: '10px',
      border: '1px solid black',
      display: 'flex',
      flexDirection:'column',
      alignItems: 'center',}}
    >
      <Typography variant="h6">Nutrition Table</Typography>
      <table>
        <thead>
          <tr>
            <th style={{fontSize:'10px'}}>Micronutrient</th>
            <th style={{fontSize:'10px'}}>Value</th>
          </tr>
        </thead>
        <tbody>
          {Object.entries(obj.text).map(([key, value]) => (
            <tr key={key}>
              <td style={{fontSize:'8px'}}>{capitalizeFirstLetter(key)}</td>
              <td style={{fontSize:'8px'}}>{value}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {/* <img src={`data:image/jpeg;base64,${obj.image}`} width='100%'/> */}
        
    </Box>
    
  );
};

export default DonutDisplayBox;
