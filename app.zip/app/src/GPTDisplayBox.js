import React from 'react';
import { Typography, Box } from '@mui/material';


const GPTDisplayBox = ({obj}) => {
  console.log(obj, 'obj')
  
  return(
    <Box width='33vw' height='80vh' sx={{
      padding: '10px',
      border: '1px solid black',
      display: 'flex',
      flexDirection:'column',
      alignItems: 'center',}}
    >
      <Typography variant="h6">GPT Analysis</Typography>
      <Typography sx={{fontSize:'10px'}}>{obj}</Typography>        
    </Box>
    
  );
};

export default GPTDisplayBox;
