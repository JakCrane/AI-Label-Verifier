import React from 'react';
import { Button, Box } from '@mui/material';
import CheckIcon from '@mui/icons-material/Check';

const FileSubmitButton = ({formData, processedData, setProcessedData, hasBackendStarted, setHasBackendStarted}) => {

  const handleSubmit = async () => {
    console.log('backend true')
    try {
      const response = await fetch('http://localhost:8000/process', {
        method: 'POST',
        body: formData,
      });

      if (response.ok) {
      setProcessedData(data)
      const data = await response.json();
      
      
      } else {
        throw new Error('Request failed');
      }
    } 
    catch (error) {
      console.error(error);
    }};
  const handleSubmitCheat = () => {
    setHasBackendStarted(true)
  }
  
  return (
    <Box>
        <Button variant="contained" component="span" onClick={handleSubmitCheat}>
          <CheckIcon />
        </Button>
    </Box>
  );
};

export default FileSubmitButton;
