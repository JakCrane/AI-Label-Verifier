import Navbar from './Navbar';
import { Box } from '@mui/material';
import FileSelectButton from './FileSelectButton';
import FileSubmitButton from './FileSubmitButton';
import ImageSelectButton from './ImageSelectButton';
import { useState } from 'react'
import LogoDisplayBox from './LogoDisplayBox';
import DonutDisplayBox from './DonutDisplayBox';
import GPTDisplayBox from './GPTDisplayBox';
import resp from './resp.json'
function App() {

  const [hasAppStarted, setHasAppStarted] = useState(null);
  const [hasBackendStarted, setHasBackendStarted] = useState(null);
  const [imageSource, setImageSource] = useState(null);
  const [formData, setFormData] = useState(new FormData());
  const [processedData, setProcessedData] = useState(null)
  const response = resp;
  return (
    <div className="App">
      <Navbar />
      {!hasBackendStarted ?
        <Box display='flex'>
          <LogoDisplayBox obj={response.logo}></LogoDisplayBox>
          <DonutDisplayBox obj={response.donut}></DonutDisplayBox>
          <GPTDisplayBox obj={response.analysis}></GPTDisplayBox>
        </Box>
        : 
        <div>
          {hasAppStarted ?
            <Box display="flex" height='80vh'>
              <Box sx={{
                border: '1px solid black',
                padding: '2%',
                maxWidth:'65vw',
              }}>
                <img src={imageSource} className="main-img" alt='food packaging label'></img> 
              </Box>
              <Box sx={{
                border: '1px solid black',
                display: 'flex',
                width:'100%',
                flexDirection:'column',
                justifyContent: 'space-evenly',
                alignItems: 'center',

              }}>
                <p>JSON</p>
                <FileSelectButton fileKey={'json_file'} fileType={'application/json'} formData={formData} setFormData={setFormData}/>
                <p>Rules</p>
                <FileSelectButton fileKey={'text_file'} fileType={'text/plain'} formData={formData} setFormData={setFormData}/>
                <p>Logo</p>
                <FileSelectButton fileKey={'logo_image'} fileType={'image/*'} formData={formData} setFormData={setFormData}/>
                <p>Submit</p>
                <FileSubmitButton formData={formData} processedData={processedData} setProcessedData={setProcessedData} hasBackendStarted={hasBackendStarted} setHasBackendStarted={setHasBackendStarted}/>
              </Box>
            </Box>
                
          :
            <Box 
            height='80vh'
            width='100%'
            sx = {{
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
            }}>
              <ImageSelectButton hasAppStarted={hasAppStarted} setHasAppStarted={setHasAppStarted} imageSource={imageSource} setImageSource={setImageSource} formData={formData} setFormData={setFormData}/>

            </Box>
          }
        </div>
        
      }
        
    </div>
  );
}

export default App;