import React, { useState } from 'react';
import { Button, Tooltip, Box, ButtonBase } from '@mui/material';
import FileUploadIcon from '@mui/icons-material/FileUpload';
import CancelIcon from '@mui/icons-material/Cancel';

const ImageSelectButton = ({hasAppStarted, setHasAppStarted, imageSource, setImageSource, formData, setFormData}) => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [fileName, setFileName] = useState(null)

  
  const handleFileChange = (event) => {
    const image = event.target.files[0]
    setSelectedFile(image);
    setFileName(image.name);
    if (image) {
      const reader = new FileReader();

      reader.onload = (e) => {
        const dataURL = e.target.result
        setImageSource(dataURL)
      }
      reader.readAsDataURL(image);
    }
  };
  const resetFileChange = () => {
    console.log('reset called {image}')
    setSelectedFile(null);
    setFileName(null);
    setImageSource(null)
  }
  const handleConfirmation = async () => {
    if (selectedFile) {

      formData.append('image', selectedFile);
      formData.append('json_file', null);
      formData.append('text_file', null);
      formData.append('logo_image', null);
      setFormData(formData);
      setTimeout(() => {
        console.log(formData)}, 1000);
    } else {
      console.log('No file selected.');
    }
    setHasAppStarted(true);
  }

  return (
    <Box>
      {selectedFile ? 
        <div>
            <ButtonBase 
              sx={{
                border: '2px solid #1976d2',
                borderRadius: '10px',
                backgroundColor: '#1976d2',
                
              }}>
              <Tooltip title="Confirm File">
                <Button component="span" onClick={handleConfirmation} sx={{ color: 'white'}}>
                  {fileName}
                </Button>
              </Tooltip>
              <Tooltip title="Deselect File">
                <Button component="span" onClick={resetFileChange} sx={{ minWidth: 0}}>
                  <CancelIcon sx={{ color: 'white'}}/>
                </Button>
              </Tooltip>
            </ButtonBase>
        </div>
      : 
        <div>
          <input
            type="file"
            id="file-input"
            accept="image/*"
            style={{ display: 'none' }}
            onChange={handleFileChange}
          />
          <label htmlFor="file-input">
            <Button variant="contained" component="span">
              <FileUploadIcon />
            </Button>
          </label>
        </div>}
    </Box>
  );
};

export default ImageSelectButton;
