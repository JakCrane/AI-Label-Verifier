from fastapi import FastAPI, UploadFile, File
import cv2
import json
import numpy as np
import base64
import uvicorn
app = FastAPI()

origins = [
    "http://localhost:3000",  # Add any additional origins that need access
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["*"],
)

@app.post("/process")
async def process_files(image: UploadFile = File(...), json_file: UploadFile = File(...), text_file: UploadFile = File(...), logo_image: UploadFile = File(...)):
    # Load and save the image
    image_data = await image.read()
    image_array = np.frombuffer(image_data, np.uint8)
    cv_image = cv2.imdecode(image_array, cv2.IMREAD_COLOR)
    cv2.imwrite("saved_image.jpg", cv_image)

    # # Load the JSON file as a dictionary
    # json_data = await json_file.read()
    # json_dict = json.loads(json_data)
    # print(json_dict)

    # # Load the text file as a list of lines
    # text_data = await text_file.read()
    # text_lines = text_data.decode().split('\n')
    # print(text_lines)

    with open("resp.json","r") as f:
        resp=json.load(f)
    return resp


uvicorn.run(app, host="0.0.0.0", port=8000)